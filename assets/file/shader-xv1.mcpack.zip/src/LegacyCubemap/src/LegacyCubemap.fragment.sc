$input v_position, v_fogColor, v_fogDistControl
#include <bgfx_shader.sh>
#include "../../bsbe.glsl"

vec4 rclouds(vec2 pos, vec3 fogcolor, float nfog, float dfog, float rain,float ftime){
    vec3 tot = vec3_splat(1.0)-nfog*.5;
    vec3 sha = mix(fogcolor.rgb,fogcolor.rgb*2.5,rain);
        sha = tl(sha);
    float den = 2.2-rain,a = 0.;
    for(int i=0; i<10; i++){
        float cm = fbm(pos,den,ftime);
        den *= .9345;
        pos *= .966;
        if(cm>0.){
            vec3 cc = ccc(fogcolor, nfog, dfog, rain);
                cc = mix(cc*3.,sha*cm,cm);
            tot = mix(tot,cc,cm);
            a += mix(0.,(1.-cm*.5)*(1.-a),cm);
        }
        sha *= .97;
    }
    return vec4(tot,a);
}

void main() {
    vec3 ajp = vec3(v_position.x,-v_position.y,-v_position.z);
    vec3 uppos = normalize(vec3(0.,abs(ajp.y),0.));
    vec3 npos = normalize(ajp);
    vec3 dpos = npos/npos.y;
	float rain = smoothstep(.6,.3,v_fogDistControl.x);
	float nfog = pow(saturate(1.-v_fogColor.r*1.5),1.2);
	float dfog = saturate((v_fogColor.r-.15)*1.25)*(1.-v_fogColor.b);
    float zenith = max0(dot(npos,uppos));
    vec3 und = sr(npos,uppos,v_fogColor.rgb,nfog,dfog,rain,v_fogDistControl.x,3.);
    vec4 color = vec4(und,pow(1.-zenith,5.));
    vec4 cloud = rclouds(dpos.xz*.8,v_fogColor.rgb,nfog,dfog,rain,v_position.w);
        color = mix(vec4(und,pow(1.-zenith,5.)),cloud,cloud.a*.65*smoothstep(1.,.95,length(npos.xz))*float(zenith>0.));
        color.rgb = tonemap(color.rgb);
    gl_FragColor = color;
}
