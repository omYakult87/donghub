#define max0(x) max(0.,x)
#define dside(x,y,z) mix(x,y,max0(abs(z)))

float rands( float n){ return fract(sin(n)*43758.5453); }
float rands( vec2 p){ return fract(cos(p.x+p.y*332.)*335.552); }
float noise2d( vec2 x){
	 vec2 p = floor(x);
	 vec2 f = fract(x);
		f = f*f*(3.0-2.0*f);
	 float n = p.x + p.y*57.0;
	return mix(mix(rands(n),rands(n+1.0),f.x),mix(rands(n+57.0),rands(n+58.0),f.x),f.y);
}
float vnt( vec2 p){
	 vec2 fp = fract(p);
	 vec2 ip = floor(p);
	 float s = 1.;
	for(int i=0; i<2; i++){
		for(int j=0; j<2; j++){
			 vec2 nb = vec2(float(j),float(i));
			 vec2 po = .3*sin(600.*vec2_splat(rands(ip+nb)));
			s = min(s,length(nb+po-fp));
		}
	}
	return s;
}
float fbm(vec2 pos,float den,float ftime){
	float tot = 0.,s = 1.;
	pos += ftime*.001;
	for(int i=0; i<3; i++){
		tot += vnt(pos)*den/s; s *= 2.2;
		pos *= 2.8;
		pos += ftime*.03;
	}
	return 1.-pow(.1,max(0.,1.-tot));
}
vec3 tl(vec3 col){ return pow(col,vec3_splat(2.2)); }
vec3 ccc(vec3 fogcolor, float nfog, float dfog, float rain){
	vec3 cloudc = mix(mix(mix(vec3(1,1,1),vec3(.15,.2,.29),nfog),vec3(1.,.3,.5),dfog),fogcolor*1.5,rain);
		cloudc = tl(cloudc);
	return cloudc;
}
vec3 csc(vec3 fogcolor, float nfog, float dfog, float rain, float fogcontrolx, float skyh){
	vec3 skyc = mix(mix(mix(vec3(0.,.35,.8),vec3(.06,.1,.2),nfog),vec3(.5,.4,.6),dfog),fogcolor.rgb*2.,rain);
	vec3 scc = mix(mix(mix(vec3(.8,.9,1.),vec3(1.,.4,.5),dfog),skyc+.15,nfog),fogcolor.rgb*2.,rain);
		skyc = tl(skyc);
		scc = tl(scc);
		skyc = mix(skyc,scc,skyh);
	if(fogcontrolx==0.)skyc=tl(fogcolor);
	return skyc;
}
vec3 sr(vec3 npos, vec3 uppos, vec3 fogcolor, float nfog, float dfog, float rain, float fogcontrolx, float atten){
	float zenith = max0(dot(npos,uppos));
	float mies = pow(1.-length(npos.zy),3.)*15.;
	float hor = pow(1.-zenith,atten)+mies*dfog;
	vec3 tsc = csc(fogcolor, nfog, dfog, rain, fogcontrolx, hor);
	return tsc;
}
vec3 tonemap(vec3 col){
	col *= 1.3;
 	col = col/(.9813*col+.1511);
	float lum = dot(col,vec3(.2125,.7154,.0721));
	col = mix(vec3_splat(lum),col,1.);
	return col;
}
