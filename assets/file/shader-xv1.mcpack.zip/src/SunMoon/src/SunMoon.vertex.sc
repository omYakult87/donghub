$input a_position
$output v_posi
#include <bgfx_shader.sh>

void main() {
    v_posi = a_position*vec3(15.0,1.0,15.0);
    gl_Position = mul(u_modelViewProj, vec4(a_position * vec3(13.0,1.0,13.0), 1.0));
}