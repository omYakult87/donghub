$input v_posi
#include <bgfx_shader.sh>

uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogColor;
uniform vec4 SunMoonColor;

#include "../../bsbe.glsl"

void main() {
    vec3 color = mix(mix(vec3(1.,.6,0.),vec3(.6,.8,1.),nfog),FogColor.rgb,rain);
	float l = length(v_posi.xz);
		color += max0(.01/pow(l*(18.-nfog*12.),8.));
 		color *= exp(.9-l)/5.;
    gl_FragColor = vec4(color*SunMoonColor.rgb,1.0);
}