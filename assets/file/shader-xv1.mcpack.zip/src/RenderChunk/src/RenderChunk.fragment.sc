$input v_color0, v_fog, v_position, v_worldpos, v_texcoord0, v_lightmapUV
#include <bgfx_shader.sh>

uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogColor;

SAMPLER2D(s_MatTexture, 0);
SAMPLER2D(s_SeasonsTexture, 1);
SAMPLER2D(s_LightMapTexture, 2);

#include "../../bsbe.glsl"

float cwav( vec2 pos){
	 vec2 mov = vec2(0.,ViewPositionAndTime.w);
	 vec2 wp = (pos*1.5)-mov*1.5;
	 vec2 wp1 = pos+mov;
	 float wave = 1.-noise2d(wp);
		wave += noise2d(wp1);
	return wave;
}
vec3 gett(vec3 nv){
	vec3 t = vec3(0,0,0);
	if(nv.x>0.){ t = vec3(0,0,-1);
	} else if(-nv.x>0.){ t = vec3(0,0,1);
	} else if(nv.y>0.){ t = vec3(1,0,0);
	} else if(-nv.y>0.){ t = vec3(1,0,0);
	} else if(nv.z>0.){ t = vec3(1,0,0);
	} else if(-nv.z>0.){ t = vec3(-1,0,0);
	}
	return normalize(t);
}
vec3 calcnw(vec3 nv,vec2 cpos){
	 float w1 = cwav(cpos);
	 float w2 = cwav(vec2(cpos.x-.02,cpos.y));
	 float w3 = cwav(vec2(cpos.x,cpos.y-.02));
	 float dx = w1-w2,dy=w1-w3;
	vec3 wn = normalize(vec3(dx,dy,1.))*.5+.5;
	vec3 t = gett(nv);
	vec3 b = normalize(cross(t,nv));
	mat3 tbn = mat3(t.x,b.x,nv.x,t.y,b.y,nv.y,t.z,b.z,nv.z);
		wn = wn*2.-1.;
		wn = normalize(mul(wn,tbn));
	return wn;
}
float fschlick(float f0,float ndv){
	return f0+(1.-f0)*pow(1.-ndv,5.);
}
vec4 reflection(vec4 diff,vec3 wpos,vec3 n,vec3 uppos,vec3 lsc,vec2 uv1,float ndv,float ndh){
	vec3 rv = reflect(normalize(wpos),n);
	vec3 skyc = sr(rv,uppos,4.);
	float fresnel = fschlick(.5,ndv);
	diff = vec4(diff.rgb*.3,.5);
	diff = mix(diff,vec4(skyc+lsc*.7,1.),fresnel);
		rv = rv/rv.y;
	float cm = fbm(rv.xz*.4,1.43)*max0(dot(rv,uppos));
	vec3 cc = ccc();
	diff = mix(diff,vec4(cc,1.),cm*fresnel*.3);
	diff += pow(ndh,256.)*vec4(skyc,1.)*dfog;
	diff.rgb *= max(uv1.x,uv1.y);
	return diff;
}
vec3 illum(vec3 diff,vec3 nv,vec3 lsc,vec2 uv1,float lmb,float cog,bool waterd){
	float dusk = min(smoothstep(.3,.5,lmb),smoothstep(1.,.8,lmb))*(1.-rain);
	float night = smoothstep(1.,.2,lmb);
	 float smap = 1.;
		smap = dside(smap,0.,nv.x);
		smap = mix(smap,0.,smoothstep(.94,.92,uv1.y));
		smap = mix(smap,0.,rain);
	if(!waterd)smap = mix(smap,0.,smoothstep(.6,.3,cog));
		smap = mix(smap,1.,smoothstep(lmb*uv1.y,1.,uv1.x));
	vec3 almap = vec3(.3,.4,.6)*mix(1.,0.,saturate(rain*.25+night));
		almap *= uv1.y;
	vec3 ambc = mix(mix(vec3(1.,.9,.9),vec3(1.,.5,.3),dusk),vec3(0.,.03,.15),night);
		almap += lsc;
		almap += ambc*smap*uv1.y;
	diff *= almap;
	return diff;
}

void main() {
    vec4 diffuse;

#if defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY)
    diffuse.rgb = vec3(1.0, 1.0, 1.0);
#else
    diffuse = texture2D(s_MatTexture, v_texcoord0);

#if defined(ALPHA_TEST)
    if (diffuse.a < 0.5) {
        discard;
    }
#endif

#if defined(SEASONS) && (defined(OPAQUE) || defined(ALPHA_TEST))
    diffuse.rgb *=
        mix(vec3(1.0, 1.0, 1.0),
            texture2D(s_SeasonsTexture, v_color0.xy).rgb * 2.0, v_color0.b);
    diffuse.rgb *= v_color0.aaa;
#else
    diffuse *= v_color0;
#endif
#endif

#ifndef TRANSPARENT
    diffuse.a = 1.0;
#endif

	vec3 nv = normalize(cross(dFdx(v_position.xyz),dFdy(v_position.xyz)));
	vec3 n = nv;
	float wflag = 0.;
	bool waterd = v_color0.a>0.4&&v_color0.a<.6;
#if !defined(SEASONS) && !defined(ALPHA_TEST)
	if(waterd){ n = calcnw(nv,v_position.xz); wflag = 0.5; }
#endif
	float lmb = texture2D(s_LightMapTexture,vec2(0,1)).r;
	float bls = mix(mix(0.,v_lightmapUV.x,smoothstep(lmb*v_lightmapUV.y,1.,v_lightmapUV.x)),v_lightmapUV.x,rain*v_lightmapUV.y);
	vec3 lsc = vec3(1.,.35,0.)*bls+pow(bls,5.)*.8;
	diffuse.rgb = tl(diffuse.rgb);
	diffuse.rgb = illum(diffuse.rgb,n,lsc,v_lightmapUV,lmb,v_color0.g,waterd);
	vec3 vdir = normalize(-v_worldpos);
	vec3 lpos = normalize(vec3(cos(2.96706),sin(2.96706),0.));
	float ndv = max(.001,dot(n,vdir));
	float ndh = max(.001,dot(n,normalize(vdir+lpos)));
	vec3 uppos = normalize(vec3(0.,abs(v_worldpos.y),0.));
	if(wflag>.4&&wflag<.6)diffuse = reflection(diffuse,v_worldpos,n,uppos,lsc,v_lightmapUV,ndv,ndh);
if(FogAndDistanceControl.x==0.0){
	float caus = cwav(v_position.xz);
	if(!waterd)diffuse.rgb = vec3(.3,.5,.8)*diffuse.rgb+saturate(caus)*diffuse.rgb*v_lightmapUV.y;
	diffuse.rgb += (1.-v_lightmapUV.y)*pow(v_lightmapUV.x,3.)*sqrt(diffuse.rgb);
	diffuse.rgb = mix(diffuse.rgb,tl(FogColor.rgb),pow(v_fog.a,5.));
}else{
	float fresnel = fschlick(.05,ndv);
	diffuse.rgb = mix(diffuse.rgb,csc(fresnel),(fresnel*rain*nv.y)*.2*smoothstep(.845,.87,v_lightmapUV.y));
}
	vec3 newfc = sr(normalize(v_worldpos),uppos,2.5);
	float fogf = max0(length(v_worldpos)/FogAndDistanceControl.z);
		fogf = mix(pow(fogf,2.)*.3,fogf*1.2,rain);
	diffuse.rgb = mix(diffuse.rgb,newfc,fogf);
	diffuse.rgb = tonemap(diffuse.rgb);

    gl_FragColor = diffuse;
}